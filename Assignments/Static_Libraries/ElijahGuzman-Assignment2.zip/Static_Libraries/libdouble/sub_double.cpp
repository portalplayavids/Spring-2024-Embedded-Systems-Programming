// Elijah Guzman - NZE594
// Date: 02/01/2024
// Description: Basic Subtraction program for ONLY DOUBLE data types.

#include "double_arithmetic.h"

double sub_double(double a, double b) {
    return a - b;
}
