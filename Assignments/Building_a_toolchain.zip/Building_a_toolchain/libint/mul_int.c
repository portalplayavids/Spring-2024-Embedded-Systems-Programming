// Elijah Guzman - NZE594
// Date: 02/01/2024
// Description: Basic Addition program for ONLY INT data types.

#include "int_arithmetic.h"

int mul_int(int a, int b){
    return a * b;
}