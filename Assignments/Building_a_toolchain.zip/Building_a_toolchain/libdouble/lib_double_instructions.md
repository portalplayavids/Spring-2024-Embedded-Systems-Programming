# Part 2: Double Arithmetic Library in C++
### Implement similar arithmetic functions as in Part 1, but for double precision floating-point numbers.

* Provide a header file (`double_arithmetic.h`) with appropriate function declarations. (remember to use extern "C")

* Compile these into a static library named `libdoublearithmetic.a`
